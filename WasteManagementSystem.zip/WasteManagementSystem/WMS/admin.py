from django.contrib import admin
from .models import Place,Garbage,Manager,DumpArea,Vehicle,Request
admin.site.register(Place)
admin.site.register(Garbage)
admin.site.register(Manager)
admin.site.register(DumpArea)
admin.site.register(Vehicle)
admin.site.register(Request)
# Register your models here.
