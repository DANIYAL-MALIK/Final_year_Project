from django.apps import AppConfig


class WmsConfig(AppConfig):
    name = 'WMS'
